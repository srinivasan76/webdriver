package com.wipro.testcases;

import java.io.IOException;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.wipro.testbases.Base;
import com.wipro.utilities.AllCommonMethods;
import com.wipro.utilities.DataProviderClass;
import com.wipro.utilities.EditInformationPage;
import com.wipro.utilities.MyAccountPage;

public class TC02_LoginAndEdit extends Base {

	@BeforeTest
	public void setUp() throws IOException {

		driver = initialization();
		maximize(driver);
		String url = getProperties().getProperty("url");
		driver.get(url);
	}

	@Test(dataProvider = "getLoginData", dataProviderClass = DataProviderClass.class)
	public void loginAndEdit(String e_mail, String password) throws IOException {
		AllCommonMethods acm = new AllCommonMethods();
		acm.getLogin(driver, e_mail, password, "TC02_login");

		MyAccountPage map = new MyAccountPage(driver);
		map.getEditAccount().click();

		EditInformationPage eip = new EditInformationPage(driver);
		eip.getEditTelephone().clear();
		eip.getEditTelephone().sendKeys("9942325636");
		eip.getSubmit().click();

		WebElement update_element = map.getUpdateMsg();
		acm.getScreenShotAtParticular(driver, update_element, "update_msg");

		acm.getLogout(driver, "TC02");

	}

	@AfterTest
	public void tearDown() throws IOException {
		driver.quit();
	}

}
