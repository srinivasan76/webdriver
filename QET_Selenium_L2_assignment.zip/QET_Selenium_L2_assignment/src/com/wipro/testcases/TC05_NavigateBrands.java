package com.wipro.testcases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.wipro.testbases.Base;
import com.wipro.utilities.AllCommonMethods;
import com.wipro.utilities.BrandPage;
import com.wipro.utilities.DataProviderClass;
import com.wipro.utilities.HomePage;
import com.wipro.utilities.MyAccountPage;

public class TC05_NavigateBrands extends Base {

	@BeforeTest
	public void setUp() throws IOException {

		driver = initialization();
		maximize(driver);
		String url = getProperties().getProperty("url");
		driver.get(url);
	}

	@Test(dataProvider = "getLoginData", dataProviderClass = DataProviderClass.class)
	public void validation(String e_mail, String password) throws IOException {
		AllCommonMethods acm = new AllCommonMethods();
		acm.getLogin(driver, e_mail, password, "TC05_login");

		MyAccountPage map = new MyAccountPage(driver);
		map.getYourStore().click();

		HomePage hp = new HomePage(driver);
		hp.getBrands().click();

		BrandPage bp = new BrandPage(driver);
		List<WebElement> brandlist = bp.getAllBrands();
		for (int i = 0; i < brandlist.size(); i++) {
			String brandName = brandlist.get(i).getText();
			brandlist.get(i).click();
			acm.getScreenShot(driver, brandName);
			driver.navigate().back();
		}

		acm.getLogout(driver, "TC05");
	}

	@AfterTest
	public void tearDown() throws IOException {
		driver.quit();
	}

}
