package com.wipro.testcases;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.wipro.testbases.Base;
import com.wipro.utilities.AllCommonMethods;
import com.wipro.utilities.DataProviderClass;
import com.wipro.utilities.MyAccountPage;

public class TC04_ValidateMenus extends Base {

	@BeforeTest
	public void setUp() throws IOException {

		driver = initialization();
		maximize(driver);
		String url = getProperties().getProperty("url");
		driver.get(url);
	}

	@Test(dataProvider = "getLoginData", dataProviderClass = DataProviderClass.class)
	public void validation(String e_mail, String password) throws IOException {

		AllCommonMethods acm = new AllCommonMethods();
		acm.getLogin(driver, e_mail, password, "TC04_login");

		MyAccountPage map = new MyAccountPage(driver);
		int size = map.getMenuLinks().size();

		String count_size = "total menu links =" + size;
		acm.getFileWriter("menulink", count_size);
		for (int i = 0; i < size; i++) {
			String name = "link" + (i + 1) + "name :" + map.getMenuLinks().get(i).getText();
			acm.getFileWriter("menulink", name);
		}
		for (int i = 0; i < size; i++) {
			String screenShotName = "menulink" + (i + 1);
			map.getMenuLinks().get(i).click();
			acm.getScreenShot(driver, screenShotName);
		}

		acm.getLogout(driver, "TC04");
	}

	@AfterTest
	public void tearDown() throws IOException {
		driver.quit();
	}

}
