package com.wipro.testcases;

import java.io.IOException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.wipro.testbases.Base;
import com.wipro.utilities.AllCommonMethods;
import com.wipro.utilities.AppleCinemaPage;
import com.wipro.utilities.DataProviderClass;
import com.wipro.utilities.MonitorsPage;
import com.wipro.utilities.MyAccountPage;
import com.wipro.utilities.ShoppingCartPage;

public class TC03_AddProduct extends Base {

	@BeforeTest
	public void setUp() throws IOException {
		driver = initialization();
		maximize(driver);
		String url = getProperties().getProperty("url");
		driver.get(url);
	}

	@Test(dataProvider = "TC03", dataProviderClass = DataProviderClass.class)
	public void loginAndEdit(String e_mail, String password, String checkbox, String text, String selectColor,
			String textArea, String file, String date, String time, String qty)
			throws IOException, InterruptedException {

		AllCommonMethods acm = new AllCommonMethods();
		acm.getLogin(driver, e_mail, password, "TC03_login");

		MyAccountPage map = new MyAccountPage(driver);
		map.getComponents().click();
		map.getMonitors().click();
		acm.getScreenShot(driver, "components");

		MonitorsPage mp = new MonitorsPage(driver);
		String userProductName = getProperties().getProperty("productName");
		List<WebElement> productNameslist = mp.getProductNames();
		List<WebElement> productPrices = mp.getPrices();

		for (int i = 0; i < productNameslist.size(); i++) {
			String productlistName = productNameslist.get(i).getText();
			String price = productPrices.get(i).getText();
			if (productlistName.equalsIgnoreCase(userProductName)) {
				acm.getFileWriter("price", productlistName);
				acm.getFileWriter("price", price);
				mp.getAddButtons().get(i).click();
				break;
			}
		}
		Thread.sleep(4000);
		AppleCinemaPage acp = new AppleCinemaPage(driver);
		List<WebElement> checkboxlist = acp.getCheckboxes();
		for (int i = 0; i < checkboxlist.size(); i++) {
			System.out.println(checkboxlist.get(i).getText() + "   " + checkbox);
			if (checkboxlist.get(i).getText().equalsIgnoreCase(checkbox)) {
				checkboxlist.get(i).click();
				break;
			}
		}

		acp.getText().clear();
		acp.getText().sendKeys(text);
		acp.getSelectValues().click();
		Select select = new Select(acp.getSelectValues());
		System.out.println(selectColor);
		List<WebElement> selectlist = select.getAllSelectedOptions();
		for (int i = 0; i < selectlist.size(); i++) {
			System.out.println(selectlist.get(i).getText());
		}
		select.selectByVisibleText(selectColor);
		acp.getTextArea().sendKeys(textArea);
		acp.getFileUpload().sendKeys(file);
		acp.getDate().clear();
		acp.getDate().sendKeys(date);
		acp.getTime().clear();
		acp.getTime().sendKeys(time);
		acp.getDateTime().clear();
		acp.getDateTime().sendKeys(date + " " + time);
		acp.getQuantity().clear();
		acp.getQuantity().sendKeys(qty);

		acp.getAddButton().click();
//for this product i am not able to add in cart. Because, it is asking radio required and file required even aftr
		//uploading file. so i will add below product and select country and here also i am facing checkout problem.
		
	//sorry, i was not able to done this test cases.
		
		
		
		
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(acp.getRadioRequired()));
		Assert.assertTrue(acp.getRadioRequired().isDisplayed());
		driver.navigate().back();

		String product2 = "Samsung SyncMaster 941BW";
		for (int i = 0; i < productNameslist.size(); i++) {
			String productlistName = productNameslist.get(i).getText();
			String price = productPrices.get(i).getText();
			if (productlistName.equalsIgnoreCase(product2)) {
				acm.getFileWriter("price", productlistName);
				acm.getFileWriter("price", price);
				mp.getAddButtons().get(i).click();
				break;
			}
		}

		wait.until(ExpectedConditions.visibilityOf(mp.getMessage()));
		acm.getScreenShotAtParticular(driver, mp.getMessage(), "shoppingCart");
		mp.getShoppingCart().click();

		DataProviderClass dp = new DataProviderClass();
		Object[][] estimate = dp.getEstimateData();
		String country = (String) estimate[0][0];
		String state = (String) estimate[0][1];
		String post = (String) estimate[0][2];
		ShoppingCartPage scp = new ShoppingCartPage(driver);
		scp.getEstimate().click();
		scp.getCountry().click();
		Select selectCountry = new Select(scp.getCountry());
		selectCountry.selectByVisibleText(country);
		scp.getState().click();
		Select selectState = new Select(scp.getState());
		wait.until(ExpectedConditions.textToBe(By.id("input-zone"), state));
		selectState.selectByVisibleText(state);

		scp.getPost().sendKeys(post);

		scp.getQuotesButton().click();
		WebElement radio = scp.getRadio();
		wait.until(ExpectedConditions.visibilityOf(radio));
		Assert.assertTrue(radio.isDisplayed() && !radio.isSelected());
		radio.click();

		scp.getShipping().click();
		wait.until(ExpectedConditions.visibilityOf(scp.getShippingMessage()));
		Assert.assertTrue(scp.getShippingMessage().isDisplayed());
		scp.getCheckout().click();

		acm.getLogout(driver, "TC03");

	}

	@AfterTest
	public void tearDown() {
		driver.quit();
	}

}
