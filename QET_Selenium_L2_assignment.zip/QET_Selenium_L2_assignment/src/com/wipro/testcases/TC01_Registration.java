package com.wipro.testcases;

import java.io.IOException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.wipro.testbases.Base;
import com.wipro.utilities.AllCommonMethods;
import com.wipro.utilities.DataProviderClass;
import com.wipro.utilities.HomePage;
import com.wipro.utilities.RegisterPage;
import com.wipro.utilities.SuccessPage;

public class TC01_Registration extends Base {

	@BeforeTest
	public void setUp() throws IOException {

		driver = initialization();
		maximize(driver);
		String url = getProperties().getProperty("url");
		driver.get(url);
	}

	@Test(testName = "Register", dataProvider = "getRegisterData",dataProviderClass=DataProviderClass.class)
	public void registration(String first_name, String last_name, String e_mail, String telephone, String password,
			String confirm_password) throws IOException {

		HomePage hp = new HomePage(driver);
		hp.getMyAccount().click();
		hp.getRegister().click();

		RegisterPage rp = new RegisterPage(driver);
		rp.getFirstName().sendKeys(first_name);
		rp.getLastName().sendKeys(last_name);
		rp.getEmail().sendKeys(e_mail);
		rp.getTelephone().sendKeys(telephone);
		rp.getPassword().sendKeys(password);
		rp.getConfirmPassword().sendKeys(confirm_password);

		AllCommonMethods acm = new AllCommonMethods();
		if (rp.getCheckbox().isSelected()) {
			acm.getFileWriter("output", "Checkbox is checked");
		} else {
			acm.getFileWriter("output", "Checkbox is unchecked");

		}

		rp.getCheckbox().click();
		rp.getSubmit().click();

		SuccessPage sp = new SuccessPage(driver);
		String message = sp.getMessgae().getText().toString();
		acm.getFileWriter("output", message);

		acm.getScreenShot(driver, "register");

		acm.getLogout(driver, "TC01");

	}

	@AfterTest
	public void tearDown() throws IOException {
		driver.quit();
	}

}
