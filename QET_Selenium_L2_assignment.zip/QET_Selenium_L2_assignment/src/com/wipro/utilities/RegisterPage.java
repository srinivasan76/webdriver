package com.wipro.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPage {

	WebDriver driver;

	@FindBy(id="input-firstname")
	WebElement first_name;

	@FindBy(id="input-lastname")
	WebElement last_name;

	@FindBy(id="input-email")
	WebElement e_mail;

	@FindBy(id="input-telephone")
	WebElement telephone;

	@FindBy(id="input-password")
	WebElement password;

	@FindBy(id="input-confirm")
	WebElement confirm_password;
	
	@FindBy(xpath="//input[@type='checkbox']")
	WebElement checkbox;
	
	@FindBy(xpath="//input[@type='submit']")
	WebElement submit;

	public RegisterPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getFirstName() {
		return first_name;
	}

	public WebElement getLastName() {
		return last_name;
	}

	public WebElement getEmail() {
		return e_mail;
	}

	public WebElement getTelephone() {
		return telephone;
	}

	public WebElement getPassword() {
		return password;
	}
	
	public WebElement getConfirmPassword() {
		return confirm_password;
	}
	
	public WebElement getCheckbox() {
		return checkbox;
	}
	
	public WebElement getSubmit() {
		return submit;
	}
}
