package com.wipro.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EditInformationPage {

	WebDriver driver;

	@FindBy(id="input-telephone")
	WebElement edit_telephone;
	
	@FindBy(xpath="//input[@type='submit']")
	WebElement submit;
	
	public EditInformationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getEditTelephone(){
		return edit_telephone;
	}
	
	public WebElement getSubmit(){
		return submit;
				
	}
}
