package com.wipro.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import javax.imageio.ImageIO;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class AllCommonMethods {

	public void getFileWriter(String FileName, String text) throws IOException {
		File file = new File("C:\\Users\\sr20084838\\workspace\\QET_Selenium_L2_assignment\\resources\\Output_Data\\"
				+ FileName + ".txt");
		FileWriter outputFile = new FileWriter(file, true);
		outputFile.write(text + "\n");
		outputFile.close();
	}

	public XSSFSheet getSheet(String sheetName) throws IOException {
		FileInputStream fis = new FileInputStream(
				"C:\\Users\\sr20084838\\Desktop\\selenium\\QET_Selenium_assignment\\Registration1.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = null;
		for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
			sheet = workbook.getSheetAt(i);
			if (sheet.getSheetName().equalsIgnoreCase(sheetName)) {
				workbook.close();
				break;
			}

		}
		return sheet;
	}

	public void getScreenShot(WebDriver driver, String name) throws IOException {

		Screenshot screenShot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000))
				.takeScreenshot(driver);
		ImageIO.write(screenShot.getImage(), "png",
				new File(
						"C:\\Users\\sr20084838\\workspace\\QET_Selenium_L2_assignment\\resources\\runner\\screenshots\\"
								+ name + ".png"));
	}

	public void getScreenShotAtParticular(WebDriver driver, WebElement element, String name) throws IOException {

		Screenshot screenShot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000))
				.takeScreenshot(driver, element);
		ImageIO.write(screenShot.getImage(), "png",
				new File(
						"C:\\Users\\sr20084838\\workspace\\QET_Selenium_L2_assignment\\resources\\runner\\screenshots\\"
								+ name + ".png"));

	}

	public void getLogin(WebDriver driver, String e_mail, String password, String scrnshotname) throws IOException {

		HomePage hp = new HomePage(driver);
		hp.getMyAccount().click();
		hp.getlogin().click();

		LoginPage lip = new LoginPage(driver);
		lip.getEmail().sendKeys(e_mail);
		lip.getPassword().sendKeys(password);

		lip.getSubmit().click();
		getScreenShot(driver, scrnshotname);
	}

	public void getLogout(WebDriver driver, String name) throws IOException {

		MyAccountPage map = new MyAccountPage(driver);
		map.getMyAccount().click();
		map.getLogout().click();
		LogoutPage lop = new LogoutPage(driver);
		String logout_msg = name + " :" + lop.getLogoutMessage().getText().toString();
		getFileWriter("output", logout_msg);
	}

}
