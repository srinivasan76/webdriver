package com.wipro.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	WebDriver driver;

	@FindBy(xpath = "//span[text()='My Account']")
	WebElement myAccount;

	@FindBy(xpath = "//a[text()='Register']")
	WebElement register;
	
	@FindBy(xpath="//a[text()='Login']")
	WebElement login;
	
	@FindBy(xpath="//div[@class='row']/div[3]/ul/li[1]/a")
	WebElement brands;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getMyAccount() {
		return myAccount;
	}

	public WebElement getRegister() {
		return register;
	}
	
	public WebElement getlogin() {
		return login;
	}
	
	public WebElement getBrands() {
		return brands;
	}
}
