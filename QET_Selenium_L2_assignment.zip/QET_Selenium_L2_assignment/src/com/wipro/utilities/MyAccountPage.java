package com.wipro.utilities;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MyAccountPage {

	WebDriver driver;
	
	//ul[@class='nav navbar-nav']/li //ul[@class='list-unstyled']/li/a

	@FindBy(xpath="//li//a[@href='https://demo.opencart.com/index.php?route=account/edit']")
	WebElement edit_account;
	
	@FindBy(xpath="//div[@class='alert alert-success alert-dismissible']")
	WebElement update_msg;
	
	@FindBy(xpath="//a[text()='Components']")
	WebElement components; 
	
	@FindBy(partialLinkText="Monitors")
	WebElement monitors;
	
	@FindBy(xpath="//ul[@class='nav navbar-nav']/li")
	List<WebElement> menulinks;
	
	@FindBy(xpath="//h1//a")
	WebElement store;
	
	@FindBy(xpath = "//span[text()='My Account']")
	WebElement myAccount;
	
	@FindBy(xpath="//a[text()='Logout']/parent::li")
	WebElement logout;
	
	public MyAccountPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getEditAccount(){
		return edit_account;
				
	}
	
	public WebElement getUpdateMsg(){
		return update_msg;
	}
	
	public WebElement getComponents(){
		return components;
	}
	
	public WebElement getMonitors(){
		return monitors;
	}
	
	public WebElement getMyAccount(){
		return myAccount;
	}
	
	public WebElement getYourStore(){
		return store;
	}
	
	public List<WebElement> getMenuLinks(){
		return menulinks;
	}
	
	public WebElement getLogout(){
		return logout;
	}
}
