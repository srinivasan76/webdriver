package com.wipro.utilities;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BrandPage {

	WebDriver driver;

	@FindBy(xpath = "//div[@class='col-sm-3']/a")
	List<WebElement> brandlist;

	public BrandPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public List<WebElement> getAllBrands() {
		return brandlist;
	}

}
