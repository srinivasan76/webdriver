package com.wipro.utilities;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AppleCinemaPage {

	WebDriver driver;

	@FindBy(xpath = "//input[@type='checkbox']/parent::label")
	List<WebElement> checkbox;
	
	@FindBy(id="input-option208")
	WebElement text;
	
	@FindBy(id="input-option217")
	WebElement selectId;
	
	@FindBy(id="input-option209")
	WebElement textArea;
	
	@FindBy(id="button-upload222")
	WebElement fileUpload;
	
	@FindBy(id="input-option219")
	WebElement date;
	
	@FindBy(id="input-option221")
	WebElement time;
	
	@FindBy(id="input-option220")
	WebElement dateTime;
	
	@FindBy(id="input-quantity")
	WebElement quantity;
	
	@FindBy(id="button-cart")
	WebElement addButton;
	
	@FindBy(className="text-danger")
	WebElement required;

	public AppleCinemaPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public List<WebElement> getCheckboxes() {
		return checkbox;
	}
	
	public WebElement getSelectValues(){
		return selectId;
	}
	
	public WebElement getText(){
		return text;
	}
	
	
	
	public WebElement getTextArea(){
		return textArea;
	}
	
	public WebElement getFileUpload(){
		return fileUpload;
	}
	
	public WebElement getDate(){
		return date;
	}
	
	public WebElement getTime(){
		return time;
	}
	
	public WebElement getDateTime(){
		return dateTime;
	}
	
	public WebElement getQuantity(){
		return quantity;
	}
	
	public WebElement getAddButton(){
		return addButton;
	}
	
	public WebElement getRadioRequired(){
		return required;
	}
}
