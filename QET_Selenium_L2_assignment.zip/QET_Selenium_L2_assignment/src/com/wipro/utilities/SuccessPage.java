package com.wipro.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SuccessPage {

	WebDriver driver;

	@FindBy(xpath="//div[@id='content']/p[1]")
	WebElement message;
	
	@FindBy(xpath = "//span[text()='My Account']")
	WebElement myAccount;
	
	@FindBy(xpath="//a[text()='Logout']/parent::li")
	WebElement logout;
	
	public SuccessPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getMessgae(){
		return message;
	}
	
	public WebElement getMyAccount() {
		return myAccount;
	}
	
	public WebElement getLogout(){
		return logout;
	}
}
