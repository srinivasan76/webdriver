package com.wipro.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ShoppingCartPage {

	WebDriver driver;
	
	@FindBy(xpath="//a[text()='Estimate Shipping & Taxes ']")
	WebElement estimate;
	
	@FindBy(id="input-country")
	WebElement country;
	
	@FindBy(id="input-zone")
	WebElement state;
	
	@FindBy(id="input-postcode")
	WebElement post;
	
	@FindBy(id="button-quote")
	WebElement quotesButton;
	
	@FindBy(xpath="//input[@type='radio']")
	WebElement radio;
	
	@FindBy(id="button-shipping")
	WebElement shipping;
	
	@FindBy(xpath="//div[@class='alert alert-success alert-dismissible']")
	WebElement shippingmessage;
	
	@FindBy(xpath="//a[text()='Checkout']")
	WebElement checkout;
	

	public ShoppingCartPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getEstimate() {
		return estimate;
	}
	
	public WebElement getCountry() {
		return country;
	}
	
	public WebElement getState() {
		return state;
	}
	
	public WebElement getPost() {
		return post;
	}
	
	public WebElement getQuotesButton() {
		return quotesButton;
	}
	
	public WebElement getRadio() {
		return radio;
	}
	
	public WebElement getShipping() {
		return shipping;
	}
	
	public WebElement getShippingMessage() {
		return shippingmessage;
	}
	
	public WebElement getCheckout() {
		return checkout;
	}
	
}
