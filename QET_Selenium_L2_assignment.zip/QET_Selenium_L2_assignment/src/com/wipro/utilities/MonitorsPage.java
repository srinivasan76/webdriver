package com.wipro.utilities;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MonitorsPage {

	WebDriver driver;

	@FindBy(xpath = "//div[@class='caption']/h4/a")
	List<WebElement> product_names;

	@FindBy(xpath = "//p[@class='price']")
	List<WebElement> prices;

	@FindBy(xpath = "//span[text()='Add to Cart']")
	List<WebElement> add_buttons;
	
	@FindBy(xpath="//div[@class='alert alert-success alert-dismissible']")
	WebElement shoppingmessage;
	
	@FindBy(xpath="//span[text()='Shopping Cart']")
	WebElement shoppingCart;

	public MonitorsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public List<WebElement> getProductNames() {
		return product_names;

	}

	public List<WebElement> getPrices() {
		return prices;
	}

	public List<WebElement> getAddButtons() {
		return add_buttons;
	}
	
	public WebElement getMessage(){
		return shoppingmessage;
	}
	
	public WebElement getShoppingCart(){
		return shoppingCart;
	}

}
