package com.wipro.utilities;

import java.io.IOException;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.annotations.DataProvider;

public class DataProviderClass {

	@DataProvider(name = "getRegisterData")
	public Object[][] getRegisterData() throws IOException {

		Object[][] data = new Object[1][6];
		AllCommonMethods acm = new AllCommonMethods();
		XSSFSheet sheet = acm.getSheet("Register");

		Row row = sheet.getRow(1);
		Iterator<Cell> cells = row.cellIterator();
		int i = 0;
		while (cells.hasNext()) {
			data[0][i] = cells.next().getStringCellValue();
			i++;
		}

		return data;

	}

	@DataProvider(name = "getLoginData")
	public static Object[][] getLoginData() throws IOException {

		Object[][] data = new Object[1][2];
		AllCommonMethods acm = new AllCommonMethods();
		XSSFSheet sheet = acm.getSheet("Login");

		Row row = sheet.getRow(1);
		Iterator<Cell> cells = row.cellIterator();
		int i = 0;
		while (cells.hasNext()) {
			data[0][i] = cells.next().getStringCellValue();
			i++;
		}
		return data;
	}

	@DataProvider(name = "TC03")
	public static Object[][] getProductData() throws IOException {
		
		Object[][] data = new Object[1][10];
		AllCommonMethods acm = new AllCommonMethods();
		XSSFSheet sheet = acm.getSheet("ProductOptions");
		Object[][] login = getLoginData();
		data[0][0] = login[0][0];
		data[0][1] = login[0][1];
		Iterator<Row> rows = sheet.rowIterator();
		int i = 2;
		while (rows.hasNext()) {
			Row row = rows.next();
			Cell cell = row.getCell(1);
			data[0][i] = cell.getStringCellValue();
			i++;

		}

		return data;
	}
	
	
	public Object[][] getEstimateData() throws IOException {

		Object[][] data = new Object[1][3];
		AllCommonMethods acm = new AllCommonMethods();
		XSSFSheet sheet = acm.getSheet("Estimate");

		Row row = sheet.getRow(1);
		Iterator<Cell> cells = row.cellIterator();
		int i = 0;
		while (cells.hasNext()) {
			data[0][i] = cells.next().getStringCellValue();
			i++;
		}
		return data;
	}
	 

}
