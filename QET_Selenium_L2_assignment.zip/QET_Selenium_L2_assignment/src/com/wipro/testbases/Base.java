package com.wipro.testbases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;

public class Base {

	public WebDriver driver;
	private String browserName;

	public WebDriver initialization() throws IOException {

		browserName = getProperties().getProperty("browser");

		if (browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\sr20084838\\workspace\\QET_Selenium_L2_assignment\\resources\\driverfiles\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browserName.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver",
					"C:\\Users\\sr20084838\\workspace\\QET_Selenium_L2_assignment\\resources\\driverfiles\\chromedriver.exe");
			driver = new FirefoxDriver();
		} else if (browserName.equalsIgnoreCase("internetexplorer")) {
			System.setProperty("webdriver.ie.driver",
					"C:\\Users\\sr20084838\\workspace\\QET_Selenium_L2_assignment\\resources\\driverfiles\\chromedriver.exe");
			driver = new InternetExplorerDriver();
		} else {
			System.setProperty("webdriver.safari.driver",
					"C:\\Users\\sr20084838\\workspace\\QET_Selenium_L2_assignment\\resources\\driverfiles\\chromedriver.exe");
			driver = new SafariDriver();
		}
		return driver;

	}

	public static Properties getProperties() throws IOException {
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(
				"C:\\Users\\sr20084838\\workspace\\QET_Selenium_L2_assignment\\resources\\config\\data.properties");
		prop.load(fis);

		return prop;
	}

	public void maximize(WebDriver driver) {
		driver.manage().window().maximize();
	}


}
